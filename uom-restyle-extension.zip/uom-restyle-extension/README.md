# uom-restyle-extension

This extension cleans up the user interface of blackboard for UoM and 
adds custom colour schemes as well as dark mode

To use this in your browser, click on "extensions" then "Developer mode" then
"load unpacked" and select the folder you have cloned the repository to

Turn on the extension called "Blackboard Restyle" to see the style changes appear

To choose the theme and switch between light and dark mode, click on the 
extensions button in the top right of Chrome and then "Blackboard Restyle"